#!/usr/bin/env bash

#######################
# Functions
#######################


get_cards_hashes(){
#set -x
gpu_stats=`cat /run/hive/gpu-stats.json | jq '.temp'`
	# hs is global
	hs=''
	hash=$(get_total_hashes)
	count=$((`gpu-detect AMD` + `gpu-detect NVIDIA`))
	gpuHash=$(echo "$hash/$count" | jq -nf /dev/stdin)
	for (( i=0; i < ${count} ; i++ )); do
		hs[$i]=`echo $gpuHash | awk '{ printf("%.f",$1*1000) }'`
	done
echo "${hs[@]}"
}

get_amd_cards_temp(){
	echo $(jq -c "[.temp$amd_indexes_array]" <<< $gpu_stats)
}

get_amd_cards_fan(){
	echo $(jq -c "[.fan$amd_indexes_array]" <<< $gpu_stats)
}

get_miner_uptime(){
#	local tmp=$(cat $LOG_NAME | head -n 3 | tail -n 1 | sed -e 's/].*//' | cut -b 2- )
	local start=$(stat -t -- $LOG_NAME | cut -d " " -f12)
	local now=$(date +%s)
	echo $((now - start))
}

get_total_hashes(){
	# khs is global
	local Total=`cat ${LOG_NAME} | grep -v 'type' | grep -Ea 'CPU|GPU' | tail -n 1 | tr -s " " | cut -d ' ' -f6 | sed 's/ //g' | awk '{printf "%.3f",$1/1000}'`
	echo $Total
}

get_log_time_diff(){
	local getLastLogTime=`tail -n 100 $LOG_NAME | grep -a "Stats Total" | tail -n 1 | awk {'print $1,$2'} | sed 's/[][]//g'`
	local logTime=`date --date="$getLastLogTime" +%s`
	local curTime=`date +%s`
	echo `expr $curTime - $logTime`
}

#######################
# MAIN script body
#######################

. /hive/custom/$CUSTOM_MINER/h-manifest.conf
local LOG_NAME="$CUSTOM_LOG_BASENAME.log"

[[ -z $GPU_COUNT_AMD ]] &&
	GPU_COUNT_AMD=`gpu-detect AMD`



# Calc log freshness
local diffTime=$(get_log_time_diff)
local maxDelay=120

# echo $diffTime

# If log is fresh the calc miner stats or set to null if not

	local hs=$(get_cards_hashes)					# hashes array
	local hs_units='hs'				# hashes utits
#	local temp=$(get_amd_cards_temp)	# cards temp
#	local fan=$(get_amd_cards_fan)		# cards fan
	local temp=$(jq '.temp' <<< $gpu_stats)
	local fan=$(jq '.fan' <<< $gpu_stats)
	local uptime=$(get_miner_uptime)	# miner uptime
	local algo="argon2i"					# algo

	# A/R shares by pool
	local ts=`cat ${LOG_NAME} | grep -v 'type'  | grep -Ea 'CPU|GPU' | tail -n 1 | tr -s " " | cut -d ' ' -f7`
	local rj=`cat ${LOG_NAME} | grep -v 'type'  | grep -Ea 'CPU|GPU' | tail -n 1 | tr -s " " | cut -d ' ' -f9`
	local ac=$(($ts-$rj))

	# make JSON
	stats=$(jq -nc \
				--argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
				--arg hs_units "$hs_units" \
				--argjson temp "$temp" \
				--argjson fan "$fan" \
				--arg uptime "$uptime" \
				--arg ac $ac --arg rj "$rj" \
				--arg algo "argon2i" \
				'{$hs, $hs_units, $temp, $fan, $uptime, ar: [$ac, $rj], $algo}')
	# total hashrate in khs
	khs=$(get_total_hashes)


# debug output
##echo temp:  $temp
##echo fan:   $fan
#echo stats: $stats
#echo khs:   $khs
